<?php

// CSC 337 Project Best Reads
//Judith antonio
// 1) Use a query parameter from AJAX to echo back an array of image urls.
// To return an array to a JavaScript you need json_encode. Do not hard
// code the array. This service should work if more folders are added.

$index=$_GET["index"];
    $arrayOfallfiles = glob('*');
    $bookFolder=" ";
    for($i=0;$i<count($arrayOfallfiles);$i++){
        
        if($arrayOfallfiles[$i]=="books"){
           
            $bookFolder=$arrayOfallfiles[$i];
            break;
        }
    }
   
    $Names = glob($bookFolder.'/*');
  
    $imageArray=array();
    $infoArray=array();
    $insideFolder=array();
    if($index==-1){
     for($i=0;$i<count($Names);$i++){
        $insideFolder=glob($Names[$i].'/*');
        array_push($imageArray,$insideFolder[0]); 
        
        
    }
      
            echo json_encode($imageArray);
    
    }
    else{
        $insideFolder=glob($Names[$index].'/*');
        $str="<div class='onereview'><img  src='". $insideFolder[0]."'><div class='thedetails'>";
        
        $arr=getinfo($insideFolder[2]);
        for($i=0;$i<count($arr);$i++){
            if($i==0)
                $str.="<b>".$arr[$i]."</b><br>";
            else
                $str.=$arr[$i];
        }
       // $str.="<br>";
        $str.="<p>";
            $arr=getinfo($insideFolder[1]);
            for($i=0;$i<count($arr);$i++){
                $str.=$arr[$i];}
                $str.="</p>";
                
                $arr=getinfo($insideFolder[3]);
                for($i=0;$i<count($arr);$i++){
                    
                    if($i==0)
                        $str.="<b>".$arr[$i];
                    else  if($i==1){
                        for($j=0;$j<$arr[$i];$j++){
                            $str.="*";
                        }
                        $str.="</b><br>";
                        }
                        else
                    $str.=$arr[$i];
                }
              
                    
                    $str.="</div></div>";
                echo json_encode($str);
        }
        
        
        
        // 2) Use a different query parameter to echo back the html for one information
        // page containing the book cover, title, author, ...
    
    function getinfo($filname){
        $arr=array();
        $file = fopen ( $filname, "r" );
        while ( ($line = fgets ( $file )) ) {
            array_push($arr,$line);
        }
        fclose ($file);
        return $arr;
    }

///$urls = ["./books/2001spaceodessy", "./books/wizardofoz"];
//echo json_encode($urls);
// Output would be this (json_encode adds an escape character: \ before /
// [".\/books\/2001spaceodessy",".\/books\/wizardofoz"]


// 2) Use a different query parameter to echo back the html for one information
// page containing the book cover, title, author, ...
?>