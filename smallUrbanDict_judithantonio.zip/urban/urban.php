<?php
//judith antonio
$index=$_GET["index"];
$array = array (
    "humble" => "having or showing a modest or low estimate of one's own importance<br>He was <strong>humble</strong> about his stature as one of rock history's most influential guitarists",
    "faith" => "complete trust or confidence in someone or something<br> I have <strong>faith</strong> in God.",
    "love" => "an intense feeling of deep affection.<br>I <strong>love</strong> you",
    "forgive" => "to cease to feel resentment against (an offender) <br><strong> forgive</strong> one's enemies",
    "patience"=>"the capacity to accept or tolerate delay, trouble, or suffering without getting angry or upset.<br>She treated her students with great <strong>patience</strong> and humor."
);


if($index!= "humble" && $index!= "faith"&& $index!= "love"&& $index!= "forgive" && $index!= "patience")
    echo"<strong>".$index."</strong>: not found in my small dictionary";
else
echo"<strong>".$index."</strong>:".$array[$index];

?>