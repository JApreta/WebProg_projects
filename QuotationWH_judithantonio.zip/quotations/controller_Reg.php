<?php


session_start ();
include 'model.php';  // for $theDBA, an instance of DataBaseAdaptor



unset($_SESSION['loginError'] );

if(isset($_GET['username'])  && isset($_GET['password'])) {
    
    $username=$_GET['username'];
    $passW=$_GET['password']; 
    $hashed_pwd=password_hash($passW,PASSWORD_DEFAULT);
    
    $arr=$theDBA->getNames($username);
    
    
    $arr =  $theDBA->checkCredentials( $username);
    
    if( count($arr)==0) {
        $arr =  $theDBA->addUser( $username, $hashed_pwd);
        header('Location: quotes.php');
    }
    else {
        $_SESSION['loginError'] = 'This username was taken already';
        header('Location: register.php');
    }
        
    }







/*

if( isset($_GET['opt']) && isset($_GET ['newUser'])&& isset($_GET ['newPWord'])) {
    
    $newUser = $_GET ['newUser'];
    $newPWord = $_GET ['newPWord'];
    $opt = $_GET ['opt'];
    if($opt == 2){//add user
        $hashed_pwd=password_hash($newPWord,PASSWORD_DEFAULT);
        $arr =  $theDBA->addUser( $newUser, $hashed_pwd);
       
        
    }
    

    

}
    
else if( isset($_GET['opt']) && isset($_GET ['newUser'])){
        
        $opt = $_GET ['opt'];
        $newUser = $_GET ['newUser'];
     
        if($opt == 3){//get quotes
            
            $arr=$theDBA->getNames($newUser);
            echo json_encode ($arr );
                
            
        }
    }*/
    
    
    

?>