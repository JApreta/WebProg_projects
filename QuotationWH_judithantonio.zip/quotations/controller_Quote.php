<?php
// This controller acts as the go between the view and the model.
//
// Judith antonio
//
include 'model.php';  // for $theDBA, an instance of DataBaseAdaptor






/*
if( isset($_GET['newQ']) && isset($_GET ['newAuthor'])) {
    // if( isset($_GET['option']) && isset($_GET ['newQuote'])&& isset($_GET ['newAuthor'])) {
    
    $newQuote = $_GET['newQ'];
    $newAuthor = $_GET ['newAuthor'];
    
    
        $arr = $theDBA->addQuote( $newQuote,  $newAuthor);*/



if( isset($_GET['option']) && isset($_GET ['newQuote'])&& isset($_GET ['newAuthor'])) {
   // if( isset($_GET['option']) && isset($_GET ['newQuote'])&& isset($_GET ['newAuthor'])) {
        
    $newQuote = $_GET ['newQuote'];
    $newAuthor = $_GET ['newAuthor'];
    $option = $_GET ['option'];
    if($option == 1)//add quote
        $arr = $theDBA->addQuote( $newQuote,  $newAuthor);
      

else if($option == 0){//get quotes
    
    $arr=$theDBA->getQuote();
   
    echo json_encode ( $arr );
}
}
else if( isset($_GET['option']) && isset($_GET['flag'])){
    $option = $_GET ['option'];
    $flag=$_GET['flag'];
    if($option == -1 && $flag>0){//get quotes
        
         $arr=$theDBA->setQuoteFlag(1,$flag);
        
    }
    else
        $arr=$theDBA->UnflagAllQuotes();
    
}

else if( isset($_GET['option']) && isset($_GET['rate'])){
    $option = $_GET ['option'];
    $rate=$_GET['rate'];
    if($option == 5 ){//get quotes
        
        $arr=$theDBA->addQuoteRate($rate);
        echo $arr;
        
    }
   else if($option == -5 ){//get quotes
    
    $arr=$theDBA->subQuoteRate($rate);
    echo $arr;
    
}
        
}

else if( isset($_GET['option'])){
    
    $option = $_GET ['option'];
    if($option == 0){//get quotes
        
        $arr=$theDBA->getQuote();
        
        echo json_encode ( $arr );}
        
}





?>