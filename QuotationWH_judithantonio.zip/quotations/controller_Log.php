<?php
// This file contains a bridge between the view and the model
// and redirects back to the proper page with after processing
// whatever form this code absorbs. The C in MVC (Controller)
//
// Author: judith antonio
//
session_start ();
include 'model.php'; 

unset($_SESSION['loginError'] );

if(isset($_GET['ID'])  && isset($_GET['password'])) {
    
    $username=$_GET['ID'];
    $passW=$_GET['password'];
    
   
    $arr =  $theDBA->checkCredentials( $username);
    if( count($arr)==1  && password_verify($passW, $arr[0]['hash'])) {
    
        $_SESSION['user'] = $username;
        header('Location: quotes.php');
    }
    else {
        $_SESSION['loginError'] = 'Invalid credentials';
        header('Location: Login.php');
    }
}

if (isset ( $_POST ['logout'] ) && $_POST ['logout'] === 'Logout') {
    session_destroy ();
    header ( 'Location: quotes.php' );
}
