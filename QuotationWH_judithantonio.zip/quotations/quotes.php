<!-- Judith Antonio-->
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>Quotation Service</title>
<link rel="stylesheet" type="text/css" href="style.css" />
</head>
<body onload="getAllQuotes()">
<?php session_start ();?>
<h2 id="main" >Quotation Service</h2>
<?php
if(!isset($_SESSION['user'])) {
    
   $strq='<div><a class="menu" href="register.php"> Register</a>'; 
   $strq.='<a class="menu" href="Login.php">Login</a><a class="menu" href="addQuote.php"> Add Quote</a></div> <br><br><br>  ';
   echo $strq;
}



/*<div><a class="menu" href="register.php"> Register</a> 
<a class="menu" href="Login.php">Login</a>  
<a class="menu" href="addQuote.php"> Add Quote</a> 
</div> <br><br><br>*/


else if(isset($_SESSION['user'])) {
    //echo '<h4>Hello ' . $_SESSION['user'] . '</h4>';
    $strq='<div><a class="menu" href=""> Register</a>';
    $strq.='<a class="menu" href="">Login</a><a class="menu" href="addQuote.php"> Add Quote</a></div> <br><br><br>  ';
    //echo $strq;
    
    $str='<br><div class="y"><br><form action="controller_Log.php" method="POST"><input type="submit" name="logout" value="Logout">';
    $str.='</form><button onclick="unflagAll()">Unflag All</button><br></div>';
    
    echo $strq.$str;
   
}
?>
<div id="toChange"></div>

<script>


function getAllQuotes(){
	
	
	 var ajax = new XMLHttpRequest();
	 ajax.open("GET", "controller_Quote.php?option="+ 0, true);
	 ajax.send();
	 ajax.onreadystatechange = function () {
	 if (ajax.readyState == 4 && ajax.status == 200) {
	       
	     var array = JSON.parse(ajax.responseText);

	     var str = "";
	     for (i = 0; i < array.length; i++){
	    	 str += "<div id ='"+array[i]['id']+"' class='quotes'><p>"+array[i]['quote']+ "</p><p>--"  +array[i]['author']+ "</p>"+"<br>";
	    	 str +="<button  onclick='addRate(this.parentElement.id)'>+</button>" +array[i]['rating'];
	    	 str +="<button  onclick='SubRate(this.parentElement.id)'>-</button>"
	    	 str +="<button  onclick='flagQuote(this.parentElement.id)'>flag</button></div><br>";
	     			}
	         document.getElementById("toChange").innerHTML = str;
	    
	 }
	}

	}

function addRate(i){

	//document.getElementById("toChange").innerHTML = i;

	var ajax = new XMLHttpRequest();
	 ajax.open("GET", "controller_Quote.php?option="+ 5 +"&rate="+i, true);
	 ajax.send();
	 ajax.onreadystatechange = function () {
	 if (ajax.readyState == 4 && ajax.status == 200) {
	       
		 //var array = ajax.responseText;
	//document.getElementById("toChange").innerHTML = array;
		getAllQuotes();
	}}

	
}
function SubRate(i){

	var ajax = new XMLHttpRequest();
	 ajax.open("GET", "controller_Quote.php?option="+ -5 +"&rate="+i, true);
	 ajax.send();
	 ajax.onreadystatechange = function () {
	 if (ajax.readyState == 4 && ajax.status == 200) {
	       
	
		getAllQuotes();
	}}
}

function flagQuote(i){
	//document.getElementById("toChange").innerHTML = i;

	var ajax = new XMLHttpRequest();
	 ajax.open("GET", "controller_Quote.php?option="+ -1 +"&flag="+i, true);
	 ajax.send();
	 ajax.onreadystatechange = function () {
	 if (ajax.readyState == 4 && ajax.status == 200) {
	       
		 //var array = JSON.parse(ajax.responseText);
	//document.getElementById("toChange").innerHTML = array;
		 getAllQuotes();
	}}
	
}


function unflagAll(){
	
	var ajax = new XMLHttpRequest();
	 ajax.open("GET", "controller_Quote.php?option="+ -1 +"&flag="+0, true);
	 ajax.send();
	 ajax.onreadystatechange = function () {
	 if (ajax.readyState == 4 && ajax.status == 200) {
	       
			getAllQuotes();
	}}


	}

</script>


</body>
</html>




<?php
?>