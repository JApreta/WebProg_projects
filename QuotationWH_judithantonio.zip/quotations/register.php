<!-- Judith Antonio-->
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>Quotation Service</title>
<link rel="stylesheet" type="text/css" href="style.css" />
</head>
<body>
<?php session_start ();?>
<h2>Register</h2>

<form class="Eform"  action="controller_Reg.php" method="GET">
		Username: <input type="text" name="username"> <br><br>
		Password: <input type="password" name="password"> <br> <br>
		<input  type="submit" name="Register" value="Register"> <br> <br>
<?php
  
  if( isset(  $_SESSION['loginError']))
    echo   $_SESSION['loginError'];
	
	?>


</form>

<div id="toChange"></div>

<script>
/*
function addUser(){
	//document.getElementById("toChange").innerHTML = "anae"; 
	//<form id="rg" class="Eform" >
	var newUser = document.getElementById("usr").value;
	 var newPWord = document.getElementById("psw").value;
	 var ajax = new XMLHttpRequest();
	 ajax.open("GET", "controller_Reg.php?opt="+ 2 + "&newUser=" + newUser + "&newPWord=" + newPWord, true);
	 ajax.send();
	 ajax.onreadystatechange = function () {
	 if (ajax.readyState == 4 && ajax.status == 200) {
	     var newQuote = document.getElementById("usr").value;  
	      
	 }
	}



	}


function chckNewUser(event){
	
	//event.preventDefault();
	 var ajax = new XMLHttpRequest();
	 var newUser = document.getElementById("usr").value;
	 ajax.open("GET", "controller_Reg.php?opt="+ 3 + "&newUser=" + newUser, true);
	 ajax.send();
	 ajax.onreadystatechange = function () {
	 if (ajax.readyState == 4 && ajax.status == 200) {
	    
	     
	     var array = JSON.parse(ajax.responseText);

	     if(array.length>0){
	    	 
	    	 document.getElementById("demo").innerHTML = "username tken";
	    	 document.getElementById("usr").value = "";
	    	 document.getElementById("psw").value = "";

	    	 }
	     else{
	    	 addUser();
	    	 header ( 'Location: index.php' );
	    	 

		     }
	           
	 }
	}



	}
	
function getUsers(){
	
	
	 var ajax = new XMLHttpRequest();
	 ajax.open("GET", "controller_Reg.php?opt="+ 3, true);
	 ajax.send();
	 ajax.onreadystatechange = function () {
	 if (ajax.readyState == 4 && ajax.status == 200) {
	     var newQuote = document.getElementById("usr").value; 
	     
	     var array = JSON.parse(ajax.responseText);

	     var str = "";
	     for (i = 0; i < array.length; i++)
	         str += array[i]['username']+ "<br>";

	         document.getElementById("toChange").innerHTML = str;       
	 }
	}



	}


*/
</script>


</body>
</html>




<?php
?>