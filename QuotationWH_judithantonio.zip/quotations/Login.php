<!-- Judith Antonio-->
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>Quotation Service</title>
<link rel="stylesheet" type="text/css" href="style.css" />
</head>
<body>

<?php
session_start ();

?>

<h2>Login</h2>

<form class="Eform"  action="controller_Log.php" method="GET">

		Username: <input type="text" name="ID"> <br><br>
		Password: <input type="password" name="password"> <br> <br>
	<input type="submit" name="Login" value="Login"> <br> <br>
<?php
  
  if( isset(  $_SESSION['loginError']))
    echo   $_SESSION['loginError'];
	
	?>

</form>
<script>
</script>
</body>
</html>



