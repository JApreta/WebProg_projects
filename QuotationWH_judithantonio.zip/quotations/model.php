<?php
// Judith antonio
//
class DatabaseAdaptor {
    // The instance variable used in every one of the functions in class DatbaseAdaptor
    private $DB;
    // Make a connection to the data based named 'quotes' (described in project).
    public function __construct() {
        $db = 'mysql:dbname=quotes;host=127.0.0.1;charset=utf8';
        $user = 'root';
        $password = '';
        
        try {
            $this->DB = new PDO ( $db, $user, $password );
            $this->DB->setAttribute ( PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION );
        } catch ( PDOException $e ) {
            echo ('Error establishing Connection');
            exit ();
        }
    }
    
    
    public function addQuote($quote, $author) {
        $date = date('Y-m-d H:i:s');
       $sqlQ="INSERT INTO QUOTATIONS (quote, author, rating, flagged,added) values(:quote,:author,:rating,:flagged,:added)";
       $newQuote = $this->DB->prepare( $sqlQ);
       $newQuote->bindParam(':quote', $quote);
       $newQuote->bindParam(':author', $author);
       $date = date('Y-m-d H:i:s');
       $newQuote->bindParam(':added', $date);
       $newQuote->bindValue(':rating', 0);
       $newQuote->bindValue(':flagged', 0);
       
        
        $newQuote->execute ();}
    
 
        
        public function addUser($newUser, $hashed_pwd){
            $sqlQuery=" INSERT INTO USERS (username, hash) values(:username,:hash)";

            $nUser=$this->DB->prepare($sqlQuery);
            $nUser->bindParam(':username', $newUser);
            $nUser->bindParam(':hash', $hashed_pwd);
            
            $nUser->execute ();
            
        }
        
        
        
        public function getUsers() {
            
            $stm = $this->DB->prepare( "SELECT * FROM users");
            $stm->execute ();
            
            return $stm->fetchAll ( PDO::FETCH_ASSOC );
        }
        
        
        
        public function setQuoteFlag($value,$id) {
            $sqlQ= "UPDATE quotations SET flagged=:flagged WHERE id=:id";
            
            $qFlag=$this->DB->prepare($sqlQ);
            $qFlag->bindParam(':flagged',$value);
            $qFlag->bindParam(':id', $id);
            
         $r=$qFlag->execute ();
         if($r==TRUE)
             return "pass";
             else return "fail";
            
        }
        
        
        public function UnflagAllQuotes(){
            $sqlQ= "UPDATE quotations SET flagged=:flagged";
            
            $qFlag=$this->DB->prepare($sqlQ);
            $qFlag->bindValue(':flagged',0);
           
            
            $r=$qFlag->execute ();
            
        }
        
        
        public function addQuoteRate($rate){
            
            $sqlQ= "UPDATE quotations SET rating=rating+1 WHERE id=:id";
            
            $qFlag=$this->DB->prepare($sqlQ);
           // $qFlag->bindParam(':flagged',$value);
            $qFlag->bindParam(':id', $rate);
            
            $r=$qFlag->execute ();
            if($r==TRUE)
                return "pass";
                else return "fail";
                
        }
        
        
        
        public function subQuoteRate($rate){
            
            $sqlQ= "UPDATE quotations SET rating=rating-1 WHERE id=:id";
            
            $qFlag=$this->DB->prepare($sqlQ);
            // $qFlag->bindParam(':flagged',$value);
            $qFlag->bindParam(':id', $rate);
            
            $r=$qFlag->execute ();
            if($r==TRUE)
                return "pass";
                else return "fail";
                
        }
            
    
        
    public function getQuote() {
       
         $stm = $this->DB->prepare( "SELECT * FROM quotations  where flagged = 0 ORDER BY rating DESC,added DESC");
         $stm->execute ();
        
        return $stm->fetchAll ( PDO::FETCH_ASSOC );
    }
    
    public function getNames($name) {
        
        $stm = $this->DB->prepare( "SELECT * FROM users where username='".$name."'");
        $stm->execute ();
        
        return $stm->fetchAll ( PDO::FETCH_ASSOC );
    }
    
    
    public function checkCredentials( $newUser){
        $stm = $this->DB->prepare( "SELECT * FROM users where username='".$newUser."'");
        $stm->execute ();
        
        return $stm->fetchAll ( PDO::FETCH_ASSOC );
        
    }
    
    
} // End class DatabaseAdaptor


$theDBA = new DatabaseAdaptor ();



?>