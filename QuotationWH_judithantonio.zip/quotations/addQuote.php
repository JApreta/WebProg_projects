<!-- Judith Antonio-->

<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>Quotation Service</title>
<link rel="stylesheet" type="text/css" href="style.css" />
</head>
<body>


<h2>Add quote</h2>




<form onsubmit= "addQuote()" action="quotes.php">
Quote <input type=text id="newQ" required> <br><br>
Author <input type=text id="newAuthor" required><br><br>

<button type="submit">  Add quote</button>

</form>
<div id="toChange"></div>

<script>
function addQuote(){
	
 var newQuote = document.getElementById("newQ").value;
 var newAuthor = document.getElementById("newAuthor").value;
 var ajax = new XMLHttpRequest();
 ajax.open("GET", "controller_Quote.php?option="+ 1 + "&newQuote=" + newQuote + "&newAuthor=" + newAuthor, true);
 ajax.send();
 ajax.onreadystatechange = function () {
 if (ajax.readyState == 4 && ajax.status == 200) {
     var newQuote = document.getElementById("newQ").value;        
 }
}



}

/*

function getQuote(){
	document.getElementById("toChange").innerHTML= "aba";
var newQuote = document.getElementById("newQ").value;
 var newAuthor = document.getElementById("newAuthor").value;
 var ajax = new XMLHttpRequest();
 ajax.open("GET", "controller_Quote.php?option="+ 0 + "&newQuote=" + newQuote + "&newAuthor=" + newAuthor, true);
 ajax.send();
 ajax.onreadystatechange = function () {
 if (ajax.readyState == 4 && ajax.status == 200) {
     var newQuote = document.getElementById("newQ").value;     
     var array = JSON.parse(ajax.responseText);

     var str = "";
     for (i = 0; i < array.length; i++)
         str += array[i]['quote']+ "<br>";

         document.getElementById("toChange").innerHTML = str;
    // document.getElementById("pattern").value = '';
 }
}



}

*/

</script>


</body>
</html>




<?php
?>