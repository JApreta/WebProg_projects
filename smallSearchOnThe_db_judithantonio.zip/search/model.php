 <?php
// Judith antonio
//
class DatabaseAdaptor {
  // The instance variable used in every one of the functions in class DatbaseAdaptor
  private $DB;
  // Make a connection to the data based named 'imdb_small' (described in project). 
  public function __construct() {
    $db = 'mysql:dbname=imdb_small;host=127.0.0.1;charset=utf8';
    $user = 'root';
    $password = '';
    
    try {
      $this->DB = new PDO ( $db, $user, $password );
      $this->DB->setAttribute ( PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION );
    } catch ( PDOException $e ) {
      echo ('Error establishing Connection');
      exit ();
    }
  }
  
  // Return all movie records with release date >= $year
  // as an associative PHP array.
  public function getRolesByPattern($pattern) {
    //$stmt = $this->DB->prepare( "SELECT * FROM movies where year >= " . $year );
      $stmt = $this->DB->prepare( "SELECT role FROM roles where role LIKE'%".$pattern."%'");
      
    $stmt->execute ();
    return $stmt->fetchAll ( PDO::FETCH_ASSOC );
  }
  
  
  
  // TODO 3: Return all movies records with a ranking >= $rank 
  // as an associate PHP array

  public function getActorsByPattern($pattern) {
      $stmt = $this->DB->prepare( "SELECT first_name,last_name FROM actors where first_name LIKE'%". $pattern."%' OR last_name LIKE '%". $pattern."%'");
      $stmt->execute ();
      return $stmt->fetchAll ( PDO::FETCH_ASSOC );
  }
  
  
  
 
} // End class DatabaseAdaptor

// Testing code that should not be run when a part of MVC
$theDBA = new DatabaseAdaptor ();
// $arr = $theDBA->getMoviesByYear (2000);
// print_r($arr);

// $arr = $theDBA->getMoviesByRank (6);
// print_r($arr);

 
?>