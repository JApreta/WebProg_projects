<?php
// This controller acts as the go between the view and the model.
//
// Judith antonio
//
include 'model.php';  // for $theDBA, an instance of DataBaseAdaptor

if( isset($_GET['pattern'])) {
    // Return a JSON version of a PHP array that
    // has all movies with a release year >= $year
    $pattern = $_GET ['pattern'];
    $option = $_GET ['option'];
    if($option == 0)
        $arr = $theDBA->getActorsByPattern($pattern);
    else if($option==1)
        $arr = $theDBA->getRolesByPattern($pattern);
       // print_r($arr );
    echo json_encode ( $arr );
}


// TODO 2: Ask the model for an array of all movies
// with ranking > $rank and echo back to the view





?>