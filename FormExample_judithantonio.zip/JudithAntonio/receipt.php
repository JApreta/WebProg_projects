<!-- Judith antonio -->
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Purchase Receipt</title>
<link href="purchase.css" type="text/css" rel="stylesheet">
</head>

<?php
date_default_timezone_set( 'America/Phoenix' );  
$mydate = date ( "d-M-Y" );
$howMany = intVal ( ($_GET ["quantity"]) );  
$price=$_GET["Size"];


// . . .
?>

<body>
  <div>  <!-- Use the same css rules as from Project 5, likely not class="receipt"-->
  <h3>Receipt</h3>
  <?php 
  echo 'Purchase date: ' . $mydate . ' <br>'; 
  echo "Purchased ".$howMany." item(s) of size ";
  if($price==2.00){
      echo " small at ". $price." each";
      printf( "<br>Total cost $ %.2f", $price*$howMany);}
      
      if($price==2.65){
          echo " medium at ". $price." each";
          printf( "<br>Total cost $ %.2f", $price*$howMany);}
          
    if($price==2.99){
        echo " medium at". $price." each";
        printf( "<br>Total cost $ %.2f", $price*$howMany);}
        
        $receipt="<fieldset><legend>Ship to:</legend>";
        $receipt.=$_GET["firstName"]." ".$_GET["lastName"]."<br>";
        $receipt.=$_GET["city"].", ".$_GET["state"]."<br>";
        $receipt.=$_GET["zip"];      
        $receipt.="</fieldset>";
        echo $receipt;
  ?>
  </div>
</body>
</html>