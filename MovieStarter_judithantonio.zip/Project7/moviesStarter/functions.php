<?php

function getmovieTitle($movieFolder){
    $arrayOfFileNames = glob($movieFolder.'/*');
    $linecount=0;
    $movieTitle="";
    $file = fopen ( $arrayOfFileNames[0], "r" );
    while ( ($line = fgets ( $file )) ) {
        $linecount++;
        if($linecount<=2)//add parentesis
            $movieTitle.=$line;
            if($linecount==1)
                $movieTitle.="(";
                if($linecount==2)
                    $movieTitle.=")";
        
    }
    fclose ( $file );
    
    
    //print_r($arrayOfFileNames);
    return  $movieTitle;
}


function getRating($movieFolder){
    
    $arrayOfFileNames = glob($movieFolder.'/*');
    $linecount=0;
    $movieRating="";
    $file = fopen ( $arrayOfFileNames[0], "r" );
    while ( ($line = fgets ( $file )) ) {
        $linecount++;
        if($linecount==3)
            $movieRating.=$line;
            
    }
   
    fclose ( $file );
    return  $movieRating;
}

function getOverviewImage($movieFolder){
    $arrayOfFileNames = glob($movieFolder.'/*');
    
    return $arrayOfFileNames[1];
    
}


function getOverContent($movieFolder){
    $arrayOfFileNames = glob($movieFolder.'/*');
    $OverContent=array();
    $file = fopen ( $arrayOfFileNames[2], "r" );
    while ( ($line = fgets ( $file )) ) {
        $hold=explode(":",$line);
        array_push($OverContent,$hold[0]);
        array_push( $OverContent,$hold[1]);
    }
    
    fclose ( $file );
 
    return $OverContent;   
    
}

function getListofReviews($movieFolder){
    $arrayOfFileNames = glob($movieFolder.'/*');
    $arrayOfReviewNames =array();
    
    for($i=3;$i<count($arrayOfFileNames);$i++){
        array_push($arrayOfReviewNames,$arrayOfFileNames[$i]);
    }
    return $arrayOfReviewNames;
}

function getSingleReview($fileName){
    $reviewContent=array();
    $file = fopen ( $fileName, "r" );
    while ( ($line = fgets ( $file )) ) {
        array_push($reviewContent,$line);
    }
    
    fclose ( $file );
    
    return $reviewContent;
      
}

?>
