<!DOCTYPE html>
<html>
<head>
<!-- Judith Antonio -->
<title>Movie Reviews</title>
<meta charset="utf-8" />
<link href="movies.css" type="text/css" rel="stylesheet" />
</head>
<body>
<div class="maindiv">
<div class="header">
		<img class="imgTop" src="images/rancidbanner.png" alt="Rancid Tomatoes">
	</div>
 
<?php
include 'functions.php';
$movieFolder = $_GET['movie'];
getmovieTitle($movieFolder);
echo '<div><h1>'.getmovieTitle($movieFolder).'</h1></div>';


?>


<div class="center"> <!-- main div -->
		
		<div><!-- div for the left side -->
		<div class="column">
		<?php
            
             $movieFolder = $_GET['movie'];
            if( getRating($movieFolder)<50)
                echo'<img class="imgOne" src="images/rottenlarge.png" alt="Rotten" /><span>'.getRating($movieFolder).'%</span>';
          else 
              echo'<img class="imgOnefresh" src="images/freshlarge.png" alt="Rotten" /><span>'.getRating($movieFolder).'%</span>';
    
 ?>
	</div>	
	<div class="gridLyt" ><!-- div to hold two columns of comments -->
	
	
	<div><!-- column one -->
		<?php 
		$movieFolder = $_GET['movie'];
		$arrayOfReviewNames=getListofReviews($movieFolder);
		
		
		for($i=0;$i<ceil(count($arrayOfReviewNames)/2);$i++){
		    $reviewContent=getSingleReview($arrayOfReviewNames[$i]);
		    echo'<p class="pRound"><img src="images/'.strtolower($reviewContent[1]).'.gif" alt="Fresh" class="headericon"/>';
		    echo'<q>'.$reviewContent[0].'</q></p>';
		    echo'<p><img src="images/critic.gif" alt="Critic"  />'.$reviewContent[2].' <br />';
		    echo $reviewContent[3].'</p>';
		   	    
		    
		}?>
		
		
		
	</div><!-- end of column one -->
	
	<div><!-- column 2 -->
	
	
	<?php 
		$movieFolder = $_GET['movie'];
		$arrayOfReviewNames=getListofReviews($movieFolder);
		
		
		for($i=ceil(count($arrayOfReviewNames)/2);$i<count($arrayOfReviewNames);$i++){
		    $reviewContent=getSingleReview($arrayOfReviewNames[$i]);
		    echo'<p class="pRound"><img src="images/'.strtolower($reviewContent[1]).'.gif" alt="Fresh" class="headericon"/>';
		    echo'<q>'.$reviewContent[0].'</q></p>';
		    
		    echo'<p><img src="images/critic.gif" alt="Critic"  />'.$reviewContent[2].' <br />';
		    echo $reviewContent[3].'</p>';
		    
		    
		}?>
	
	</div><!-- end of colmn 2 -->

		
		
		
		</div><!-- end of div w/2 colns -->	
	</div><!-- end of left side -->
	
	
	<div class="bColorRght" ><!-- div for right content -->
	<div >
		<?php 
		$movieFolder = $_GET['movie'];
		echo'<img class="imgRgth" src="'.getOverviewImage($movieFolder).'" alt="general overview" />';
	?>
	</div>
	
	
	
	<div class="bottonRgth">
	<dl>
	<?php 
		$movieFolder = $_GET['movie'];
		$OverContent=getOverContent($movieFolder);	
		
		for($i=0;$i<count($OverContent);$i++){
		    echo'<dt>'.$OverContent[$i].'</dt>';
		    echo'<dd>'.$OverContent[$i+1].'</dd>';
		    $i++;
		    
		}
		
		?>
	</dl>
	</div>
	</div>
	
</div><!-- fim of main div -->

</div>
</body>
</html>