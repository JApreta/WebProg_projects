<?php
// This file is a unit test for the functions you discover
// you will need. Partitioning the system into functions will
// make it much easier to echo the correct HTML code back to the browser
include 'functions.php';

echo definitionList('princessbride');

?>