<?php

session_start();
include 'model.php';

unset($_SESSION['loginError']);

if(isset($_GET['username']) && isset($_GET['password'])){
    $uname = $_GET['username'];
    $pass  = $_GET['password'];
    
    
  
    
    if($_GET['Users'] == 'Student'){
        $arr = $theDBA->verifyStudentCredentials($uname);
        if(count($arr) == 1 && password_verify($pass, $arr[0]['hash'])){
            $_SESSION['user'] = $uname.'.Student';
            
            header('Location: home.php');
        } else{
            $_SESSION['loginError'] = 'Invalid credentials';
            header('Location: login.php');
        }
    }
    else if($_GET['Users'] == 'Professor'){
        $arr = $theDBA->verifyProfessorCredentials($uname);
        if(count($arr) == 1 && password_verify($pass, $arr[0]['hash'])){
            $_SESSION['user'] = $uname.'.Professor';
            
            header('Location: home.php');
        } else{
            $_SESSION['loginError'] = 'Invalid credentials';
            header('Location: login.php');
        }
    }
}

if (isset($_POST['logout']) && $_POST ['logout'] === 'Logout') {
    session_destroy ();
    header ('Location: home.php' );
}

?>
