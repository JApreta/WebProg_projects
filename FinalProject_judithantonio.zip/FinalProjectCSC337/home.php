<!DOCTYPE html>
<html>
<title>Grade Checker</title>
<link rel="stylesheet" type="text/css" href="style.css" />
<meta name="viewport" content="width=device-width, initial-scale=1">

<body>

<?php session_start ();?>

<h1>Welcome to check your Progress</h1>
<?php


if(!isset($_SESSION['user']))  {
    $strq='<div><a class="menu" href="register.php" > Register</a> ';
    $strq.='<a class="menu" href="Login.php">Login</a></div> <br><br><br>'  ;
    echo $strq;
    
}
    
  else if(isset($_SESSION['user'])) {
      
      
             $strq= "<input id='usertype' value='".explode(".",$_SESSION['user'])[1]."' type='hidden'><h4>You are Login as  " . explode(".",$_SESSION['user'])[0]."<br><br>";
            $strq.=' <div class="dropdown "><form class="menu"  action="controller_Log.php" method="POST"><input type="submit" name="logout" value="Logout"></form></div> ';
            $strq.='<a class="dropbtn" onclick="myFunction()"  href="#" " > Courses</a><br><br><br>';
             $strq.='<div id="myDropdown" class="dropdown-content"> </div>';
               echo  $strq;
      
    }
    

?>


<div></div>

<div class="home1">
<div></div>
<div id=pf class="center">

 <div id="toChange"></div>
  <img class="center1" name="at" src="images/7.jpg" >
  <img class="center1" name="at" src="images/8.jpg" >
  <img class="center1" name="at" src="images/5.png" >
   <img class="center1" name="at" src="images/6.png" >
  <img class="center1" name="at" src="images/4.jpg" >
  
 </div>
 
 <div class="rigthSide" id="k"> </div>
  </div>
<div></div><br><br><br>
<div id='addG' class="center2">
<h2 id="jk" ></h2>
<button onclick='checkGrades()'> Check grades</button>  
<button onclick='AddGrades()'> Add grades</button > 
<button onclick='showStudentsList()'> List of Students</button>
<button onclick='closeDiv()'> close</button>

<div >
<form id='shc' class="center2"></form></div>
</div>
<?php 
	if(isset($_SESSION['user'])){
	   if(explode(".",$_SESSION['user'])[1] == 'Student'){
	        $str = '<div class="hide" id="gradesDiv"><p id="topics">Grade Item</p></div>';
	        echo $str;
	   }
	}
	
	?>

<script>

var myIndex = 0;
var courseArr= new Array();
var descArr= new Array();
var GnameArr= new Array();
var GCatArr= new Array();
var  ind=-1;
var st='';
carousel();
getCategory();
function closeDiv(){
	 document.getElementById("addG").style.display= "none";
	 document.getElementById('shc').innerHTML="";
}
var i=0;
var currentGr=-1;
function hiddenShow(chk){
/*
	var x = document.getElementById("addG");
    if (x.style.display === "none") {
        x.style.display = "block";
    } else {
        x.style.display = "none";
    }*/
    if(chk==true){
    var g = document.getElementById('pf');
	for (var i = 5;i < g.children.length; i++){

	    (function(index){
	        g.children[i].onclick = function(){
	        	document.getElementById("jk").innerHTML="You are working on "+descArr[index-5];
	        	currentGr=index-5;
	        	document.getElementById('shc').innerHTML="";
	            document.getElementById("addG").style.display = "block";
}})(i);}}}

function carousel() {
    var i;
    var x = document.getElementsByName("at");
    for (i = 0; i < x.length; i++) {
       x[i].style.display = "none";  
    }
    myIndex++;
    if (myIndex > x.length) {myIndex = 1}    
    x[myIndex-1].style.display = "block";  
    setTimeout(carousel, 9000);    
}



function showCourses(){
	courseArr= new Array();
	var ajax = new XMLHttpRequest();
	 ajax.open("GET", "controllerReg.php?opt="+ 2, true);
	 ajax.send();
	 ajax.onreadystatechange = function () {
	 if (ajax.readyState == 4 && ajax.status == 200) {
		 var arr = JSON.parse(ajax.responseText);
		var str="Your Courses<br>";
		 for(var i=0; i<arr.length; i++){
			 courseArr.push(arr[i]['name']);
			 str+='<button class="butt"  onclick="showGrades('+i+')" >'+arr[i]['name']+'</button><br>';
			 }
		 
		 
		 document.getElementById('myDropdown').innerHTML=str;
	    
	 }
	}

}
var strGr="<option selected value=''>-- Select a Grade Category --</option>";

function getDesc(){
	
	 //descArr= new Array();

		var ajax = new XMLHttpRequest();
		 ajax.open("GET", "controllerReg.php?opt=" + 4, true);
		 ajax.send();
		 ajax.onreadystatechange = function () {
		 if (ajax.readyState == 4 && ajax.status == 200) {
			 var arr = JSON.parse(ajax.responseText);
			//var str="<option selected value=''>-- Select a Grade Description --</option>";
			 for(var i=0; i<arr.length; i++){
				 descArr.push(arr[i]['name']);
				 GnameArr.push(arr[i]['category']);
					//strGr+='<option value="'+arr[i]['category']+'">'+arr[i]['category']+'</option>'
				 
					 }
			 }
			// document.getElementById('slctDsc').innerHTML=str;
			 
		    
		 }
		//}
}


function getCategory(){
	
	 //descArr= new Array();

		var ajax = new XMLHttpRequest();
		 ajax.open("GET", "controllerReg.php?opt=" + -5, true);
		 ajax.send();
		 ajax.onreadystatechange = function () {
		 if (ajax.readyState == 4 && ajax.status == 200) {
			 var arr = JSON.parse(ajax.responseText);
			//var str="<option selected value=''>-- Select a Grade Description --</option>";
			 for(var i=0; i<arr.length; i++){
				 GCatArr.push(arr[i]['name']);
			strGr+='<option value="'+arr[i]['name']+'">'+arr[i]['name']+'</option>'
								 
						 }
					 }
			
			// document.getElementById('slctDsc').innerHTML=str;
			 
		    
		 }
		
}




getDesc();
function showGrades(j){

	var userTy=document.getElementById('usertype').value;
	ind=j;
	
	if(userTy=='Professor'){
		/* FOR Professors  */

	ind=j;
	
	var contentCenter=" <h3>You are in "+courseArr[j]+"</h3><div > <form onsubmit='addNewGradeItem()'> Grade Description<input id='gD' class='kk' type='text' required>Grade Category<select id='gC' required>"+strGr+"</select><button  type='submit' id='newdiv' > ok</button></form></div><br><br><br> ";
	//+"<button   onclick='AddGrades()'> Add Grades</button> <br><br><div id='Dform' ></div> </div>";
	for(var k=0; k<descArr.length; k++){
		 contentCenter+='<button class="dropbtn"  onmouseover="hiddenShow(true)" >'+descArr[k]+'</button> '
		 }
	document.getElementById("addG").style.display= "none";
	document.getElementById('shc').innerHTML="";
	document.getElementById('pf').innerHTML=contentCenter;
	}


	/* FOR STUDENTS  */
	else{

		document.getElementById('toChange').style.display = 'none';
		document.getElementById('gradesDiv').style.display = 'block';
		var ajax = new XMLHttpRequest();
		ajax.open("GET", "controller_Grades.php?opt="+1 +"&course="+courseArr[ind],true);
		ajax.send();
		ajax.onreadystatechange = function(){
		//alert(ajax.responseText);
		if(ajax.readyState == 4 && ajax.status==200){
			var arr = JSON.parse(ajax.responseText);

//EDIT THIS TO LOOK LIKE A TABLE
			
			
			var table = '';
			table += "<table class='tMain'><tr class='tStyle'><th class='tablealignLeft'>"+ courseArr[ind]+ " Grade Item</th><th class='tablealignRight'>Grade</th></tr>";
			for(var j=0;j<GCatArr.length;j++){
				table += "<tr class='tStyle'><td class='tRFont'>"+GCatArr[j]+"</td><td></td><td></td></tr>";
				//table+= GCatArr[j]+'<br>';

			for(var i = 0; i < arr.length; i++){ 
				if(arr[i]['grade_name'] == GCatArr[j]){
					//table+=arr[i]['grade_description']+'---->'+arr[i]['grade']+'<br>';
					//points = (arr[i-2]/10).toFixed(2);
					table += "<tr class='tRFont'><td>&nbsp&nbsp&nbsp&nbsp "+arr[i]['grade_description']+"</td><td class='tablealignRight'>"+arr[i]['grade']+"%&nbsp</td></tr>";
			
			
				}
			}
			/*var table = 'Grade Items';
			for(var j=0;j<GCatArr.length;j++){

				table+= GCatArr[j]+'<br>';

			for(var i = 0; i < arr.length; i++){ 
				if(arr[i]['grade_name'] == GCatArr[j]){
					table+=arr[i]['grade_description']+'---->'+arr[i]['grade']+'<br>';*/
				}
			
			
			document.getElementById('topics').innerHTML = table;
			
			}
		//document.getElementById('topics').innerHTML = 'kkk';
		}


		}
}


function getStudentsList(){
	
	var ajax = new XMLHttpRequest();
	 ajax.open("GET", "controllerReg.php?opt="+ 3 + "&course="+courseArr[ind], true);
	 ajax.send();
	 ajax.onreadystatechange = function () {
	 if (ajax.readyState == 4 && ajax.status == 200) {
		 var arr = JSON.parse(ajax.responseText);
		 //var arr = ajax.responseText;
		 
		 if(arr.length==0)
			str="This list is Empty";
		else{
		 str="<div class='center'>Your Students<br>";
		 str+="<table class='Prtables'><tr><th class='Prtables'>First Name</th> <th class='Prtables'>Last Name</th> <th class='Prtables'>Email</th></tr>";
		}
		 for(var i=0; i<arr.length; i++){
			 var std=arr[i]['first_name']+' '+arr[i]['last_name'];
			 str+='<tr><td class="Prtables">'+ arr[i]['first_name']+'</td><td class="Prtables"> '+arr[i]['last_name']+'</td><td class="Prtables">'+arr[i]['email']+'</td></tr><br>';
			 
			// str+= arr[i]['first_name']+' '+arr[i]['last_name']+'<br>';
			 }
		 str+='</table></div>';
		
			 document.getElementById('shc').innerHTML=str;
			 
	    
	 }
	}
	
}

function showStudentsList(){

	getStudentsList();
	document.getElementById("shc").classList.toggle("show");
}


function AddGrades(){
	
		 
	var ajax = new XMLHttpRequest();
	 ajax.open("GET", "controllerReg.php?opt="+ 3 + "&course="+courseArr[ind], true);
	 ajax.send();
	 ajax.onreadystatechange = function () {
	 if (ajax.readyState == 4 && ajax.status == 200) {
		 var arr = JSON.parse(ajax.responseText);
		
		var str="<table class='Prtables'><tr><th class='Prtables'>First Name</th> <th class='Prtables'>Last Name</th> <th class='Prtables'>Grade</th></tr>";
		 for(var i=0; i<arr.length; i++){
			 var std=arr[i]['first_name']+' '+arr[i]['last_name'];
			 
			 str+='<tr><td class="Prtables">'+ arr[i]['first_name']+'</td><td class="Prtables"> '+arr[i]['last_name']+'</td><td class="Prtables"><input type="hidden" ><input type="number" min="0" max="100" id="gr'+i+'"><button value="gr'+i+'.'+arr[i]['username']+'" onclick="uploadGrade(this)">Add</button></td></tr><br>';
			 }
		 str+='</table>';
		
			 document.getElementById('shc').innerHTML=str;//}
			 
	    
	 }
	}
			
	
}

function addNewGradeItem(){
	var desc = document.getElementById("gD").value;
	var cat=document.getElementById("gC").value;
	
	var ajax = new XMLHttpRequest();
	 ajax.open("GET", "controllerReg.php?GD="+ desc + "&GC="+cat, true);
	 ajax.send();
	 ajax.onreadystatechange = function () {
	 if (ajax.readyState == 4 && ajax.status == 200) {
		 
		
	 }
	}
		
	 descArr.push(desc);
	 GnameArr.push(cat);
	 showGrades(ind);
}

function checkGrades(){
	
	var str="";
	var ajax = new XMLHttpRequest();
	 ajax.open("GET", "controllerReg.php?opt="+ 8 + "&course="+courseArr[ind] +"&gradeDesc="+descArr[currentGr], true);
	 ajax.send();
	 ajax.onreadystatechange = function () {
	 if (ajax.readyState == 4 && ajax.status == 200) {
		 var arr = JSON.parse(ajax.responseText);
		if(arr.length==0)
			str="This list is Empty";
		else{
		 str="<table class='Prtables'><tr><th class='Prtables'>First Name</th> <th class='Prtables'>Last Name</th> <th class='Prtables'>Grade</th></tr>";
		 for(var i=0; i<arr.length; i++){
			 var std=arr[i]['first_name']+' '+arr[i]['last_name'];
			 
			 str+='<tr><td class="Prtables">'+ arr[i]['first_name']+'</td><td class="Prtables"> '+arr[i]['last_name']+'</td><td class="Prtables"><input type="hidden" ><input type="number" min="0" max="100" value="'+arr[i]['grade']+'" id="gr'+i+'"> <button value="gr'+i+'.'+arr[i]['username']+'" onclick="updateGrade(this)">Update</button></td></tr><br>';
			 }
		 str+='</table>';
		}
			 document.getElementById('shc').innerHTML=str;//}
			 
	    
	 }
	}	
}


function updateGrade(id){
	var res = (id.value).split(".");
	var h=document.getElementById(res[0]).value;
	
	var ajax = new XMLHttpRequest();
	 ajax.open("GET", "controllerReg.php?opt="+ 6 + "&course="+courseArr[ind] + "&stdUsername="+res[1]+ "&grade="+h +"&desc="+descArr[currentGr], true);
	 ajax.send();
	 ajax.onreadystatechange = function () {
	 if (ajax.readyState == 4 && ajax.status == 200) {
		
	 }
	}//
	
}




function uploadGrade(id){
	var res = (id.value).split(".");
	var h=document.getElementById(res[0]).value;
	
	var ajax = new XMLHttpRequest();
	 ajax.open("GET", "controllerReg.php?opt="+ 5 + "&course="+courseArr[ind] + "&stdUsername="+res[1]+ "&grade="+h +"&desc="+descArr[currentGr] +"&Gname="+GnameArr[currentGr], true);
	 ajax.send();
	 ajax.onreadystatechange = function () {
	 if (ajax.readyState == 4 && ajax.status == 200) {
		
	 }
	}//
	
}






function myFunction() {
	showCourses();
    document.getElementById("myDropdown").classList.toggle("show");
}
window.onclick = function(event) {
	  if (!event.target.matches('.dropbtn')) {
		  
	    var dropdowns = document.getElementsByClassName("dropdown-content");
	    var i;
	    for (i = 0; i < dropdowns.length; i++) {
	      var openDropdown = dropdowns[i];
	      if (openDropdown.classList.contains('show')) {
	        openDropdown.classList.remove('show');
	      }
	    }
	  }
	}



 

 


 
</script>

</body>
</html>
