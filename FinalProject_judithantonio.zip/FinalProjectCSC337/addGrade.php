<!DOCTYPE html>
<html>
<title>home</title>
<link rel="stylesheet" type="text/css" href="style.css" />
<meta name="viewport" content="width=device-width, initial-scale=1">

<body>


<form class="modal-content" action="controllerReg.php" method="GET">
 <div class="container">
		<fieldset>
		<select id="slctStd" onchange="getStudentsList()"  required>
		</select><br>
		
		<select id="slctDsc" name="SecQ" required>
		</select>
		<br>Grade <input type="text">
		<button> Add</button>
		 </fieldset>
		

</div>
</form>
<script >

var myIndex = 0;
var courseArr= new Array();
var studentsArr= new Array();
var  ind=-1;

function showCourses(){
	courseArr= new Array();
	var ajax = new XMLHttpRequest();
	 ajax.open("GET", "controllerReg.php?opt="+ 2, true);
	 ajax.send();
	 ajax.onreadystatechange = function () {
	 if (ajax.readyState == 4 && ajax.status == 200) {
		 var arr = JSON.parse(ajax.responseText);
		//var str="Your Courses<br>";
		 for(var i=0; i<arr.length; i++){
			 courseArr.push(arr[i]['name']);
			 //str+='<button class="butt"  onclick="showGrades('+i+')" >'+arr[i]['name']+'</button><br>';
			 }
		 
		 
		 //document.getElementById('myDropdown').innerHTML=str;
	    
	 }
	}

}

function getStudentsLit(){
	showCourses();
	var ajax = new XMLHttpRequest();
	 ajax.open("GET", "controllerReg.php?opt="+ 3 + "&course="+courseArr[ind], true);
	 ajax.send();
	 ajax.onreadystatechange = function () {
	 if (ajax.readyState == 4 && ajax.status == 200) {
		 var arr = JSON.parse(ajax.responseText);
		 //var arr = ajax.responseText;
		var str="<option selected value=''>-- Select a Grade Description --</option>";
		 for(var i=0; i<arr.length; i++){
			 var strc= arr[i]['first_name']+' '+arr[i]['last_name']+'<br>';
			 str+='<option value="'+strc+'">'+strc+'</option>'
			 
			 }
		
		// if(arr.length==0){
			 document.getElementById('slctStd').innerHTML=str;//}
			 
	    
	 }
	}
	
}

/*
function AddGrades(){
	var ajax = new XMLHttpRequest();
	 ajax.open("GET", "controllerReg.php?opt="+ 3 + "&course="+courseArr[ind], true);
	 ajax.send();
	 ajax.onreadystatechange = function () {
	 if (ajax.readyState == 4 && ajax.status == 200) {
		 var arr = JSON.parse(ajax.responseText);
		
		 
		var str="<form><select>";


		 str+="<option selected value=''>-- Select a a Student --</option>";
		 for(var i=0; i<arr.length; i++){
			 str+='<option value="'+arr[i]['first_name']+'">'+arr[i]['first_name']+' '+arr[i]['last_name']+'</option>'
			 }
		

		 str+='<input type="text" id="grd"></select></form>';
		
			 document.getElementById('Dform').innerHTML=str;
	    
	}
	}
	
}
*/
window.onload = function(){
	

	
	var ajax = new XMLHttpRequest();
	 ajax.open("GET", "controllerReg.php?opt=" + 4, true);
	 ajax.send();
	 ajax.onreadystatechange = function () {
	 if (ajax.readyState == 4 && ajax.status == 200) {
		 var arr = JSON.parse(ajax.responseText);
		var str="<option selected value=''>-- Select a Grade Description --</option>";
		 for(var i=0; i<arr.length; i++){
			 str+='<option value="'+arr[i]['name']+'">'+arr[i]['name']+'</option>'
			 }
		 
		 document.getElementById('slctDsc').innerHTML=str;
		 
	    
	 }
	}
}

</script>
</body>
</html>
