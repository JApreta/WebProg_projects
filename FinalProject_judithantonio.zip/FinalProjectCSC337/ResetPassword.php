<!DOCTYPE html>
<html>
<title>home</title>
<link rel="stylesheet" type="text/css" href="style.css" />
<meta name="viewport" content="width=device-width, initial-scale=1">

<body>

<?php session_start ();?>

<h1>Reset Password</h1>


<div>
 <form  class="Eform" action="controller_Log.php" method="POST">
 
 Username <input class='kll' type="text" name="myusernama" >
 
    </form>


</div> <br><br><br>






<script>



</script>

</body>
</html>
