<!-- Judith Antonio-->
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>Grade Checker</title>
<link rel="stylesheet" type="text/css" href="style.css" />
</head>
<body >
<?php session_start ();?>
<h2>Register</h2>


  
 <form class="modal-content" action="controllerReg.php" method="GET">
 <div class="container">
		First Name: <input class='kll' type="text" name="firstname" pattern="[A-Z a-z]*" required> <br><br>
		Last Name: <input class='kll' type="text" name="lastname" pattern="[A-Z a-z]*" required> <br> <br>
		Email: <input class='kll' type="email" name="email" required> <br> <br>
		Username: <input class='kll' type="text" name="username" required pattern=".{6,}" required title="6 characters minimum"> <br><br>
		Password: <input class='kll' type="password" name="password" required pattern=".{8,}" required title="8 characters minimum"> <br> <br>
		<input id='sh' type="hidden" value="nada" name='Clist'>
		
		Register as:<input type="radio" name="Users" id="std" value="student" required>Student
		<input type="radio" name="Users" id="prf" value="teacher" required>Professor<br><br>
			
		
		<fieldset ><legend>Select a Course</legend> 
		<select id="slC"  onchange="showCourses()"required></select>
		</fieldset><br><br><br>
		
		
		<fieldset > <legend>Your coures</legend> 
		 <div id="crs" ></div>
		 </fieldset>
		
		
		
		
		
		<br><input  type="submit" name="Register" value="Register"> <br> <br>
		
</div>		
<?php
  
  if( isset(  $_SESSION['loginError']))
    echo   $_SESSION['loginError'];
	
	?>


</form>






<script>
var strc='';
function showCourses(){
	strc+=document.getElementById('slC').value+'<br>';
	document.getElementById('sh').value=strc;
	document.getElementById('crs').innerHTML=strc ;
	
}
	window.onload = function(){
	

		strc='';
		var ajax = new XMLHttpRequest();
		 ajax.open("GET", "controllerReg.php?opt=" + 1, true);
		 ajax.send();
		 ajax.onreadystatechange = function () {
		 if (ajax.readyState == 4 && ajax.status == 200) {
			 var arr = JSON.parse(ajax.responseText);
			var str="<option selected value=''>-- Select a Security Question --</option>";
			 for(var i=0; i<arr.length; i++){
				 str+='<option value="'+arr[i]['name']+'">'+arr[i]['name']+'</option>'
				 }
			 
			 document.getElementById('slC').innerHTML=str;
			 document.getElementById('crs').innerHTML=document.getElementById('slC').value;
		    
		 }
		}


		
}
</script>
</body>
</html>




<?php
?>