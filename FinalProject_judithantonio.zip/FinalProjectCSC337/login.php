<!-- Judith Antonio-->
<!-- Bobby Hizt-->
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>Quotation Service</title>
<link rel="stylesheet" type="text/css" href="style.css" />
</head>
<body>
<?php session_start ();?>
<div class="home1">
<div></div>
<div>
<h2>Login</h2>
<form class="Eform" action="controller_Log.php" method="GET">
	<br>
	Login as:<input type="radio" name="Users" id="std" value="Student" required>Student
	<input type="radio" name="Users" id="prf" value="Professor" required>Professor
	<br><br>
	Username: <input class='kll' type='text' id='uname' name='username' required>
	<br><br>
	Password: <input class='kll' type='password' id='pass' name='password' required>
	<br><br>
	<input type='submit' value='Login' name='login'>
	
	
<?php
  
  if( isset(  $_SESSION['loginError']))
    echo   $_SESSION['loginError'];
	
	?>


</form>
</div></div>
</body>
</html>

