<?php

// Judith antonio
//Bobby Hizt

class DatabaseAdaptor {
    
    // The instance variable used in every one of the functions in class DatbaseAdaptor
    private $DB;
    // Make a connection to the data based named 'imdb_small' (described in project).
    public function __construct() {
        $db = 'mysql:dbname=University;host=127.0.0.1;charset=utf8';
        $user = 'root';
        $password = '';
        
        try {
            $this->DB = new PDO ( $db, $user, $password );
            $this->DB->setAttribute ( PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION );
        } catch ( PDOException $e ) {
            echo ('Error establishing Connection');
            exit ();
        }
    }
    
    
    public function addStudent($first_name,$last_name,$email,$username, $hashed_pwd) {
        
        $q = $this->DB->prepare( "INSERT INTO STUDENTS (first_name,last_name,email,username,hash) values(:first_name,:last_name,:email,:username,:hash)");
        $q->bindParam(':first_name', $first_name);
        $q->bindParam(':last_name', $last_name);
        $q->bindParam(':email', $email);
        $q->bindParam(':username', $username);
        $q->bindParam(':hash', $hashed_pwd);  
       // $q->bindParam(':securityQuestion', $secQuestion);
       // $q->bindParam(':securityAnswer', $hashAns);
        
        
        $q->execute ();}
        
        public function addTeacher($first_name,$last_name,$email,$username, $hashed_pwd) {
            
            $q = $this->DB->prepare( "INSERT INTO TEACHERS (first_name, last_name, email, username,hash) values(:first_name,:last_name,:email,:username,:hash)");
            $q->bindParam(':first_name', $first_name);
            $q->bindParam(':last_name', $last_name);
            $q->bindParam(':email', $email);
            $q->bindParam(':username', $username);
            $q->bindParam(':hash', $hashed_pwd);
           // $q->bindParam(':securityQuestion', $secQuestion);
           // $q->bindParam(':securityAnswer', $hashAns);
            
            
            $q->execute ();}
            
            
          
        
        public function getStudents() {
            
            $stm = $this->DB->prepare( "SELECT * FROM students");
            $stm->execute ();
            
            return $stm->fetchAll ( PDO::FETCH_ASSOC );
        }
        
        
        public function getStudentUsernames($name) {
            
            $q = $this->DB->prepare( "SELECT * FROM students where username='".$name."'");
            $q->execute ();
            
            return $q->fetchAll ( PDO::FETCH_ASSOC );
        }
        
        
        public function getTeacherUsernames($name) {
            
            $q = $this->DB->prepare( "SELECT * FROM students where username='".$name."'");
            $q->execute ();
            
            return $q->fetchAll ( PDO::FETCH_ASSOC );
        }
        
        public function checkStudentCredentials( $newUser){
            $q = $this->DB->prepare( "SELECT * FROM students where username='".$newUser."'");
            $q->execute ();
            
            return $q->fetchAll ( PDO::FETCH_ASSOC );
            
        }
        
        public function checkTeacherCredentials( $newUser){
            $q = $this->DB->prepare( "SELECT * FROM teachers where username='".$newUser."'");
            $q->execute ();
            
            return $q->fetchAll ( PDO::FETCH_ASSOC );
            
        }
        
        public function verifyStudentCredentials($uname){
            $stmt = $this->DB->prepare("SELECT * FROM students where username = :uname");
            $stmt->bindParam(':uname', $uname);
            $stmt->execute();
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        }
        
        public function verifyProfessorCredentials($uname){
            $stmt = $this->DB->prepare("SELECT * FROM teachers where username = :uname");
            $stmt->bindParam(':uname', $uname);
            $stmt->execute();
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        }
        
        public function getStdId($Stdname){
            $stmt = $this->DB->prepare("SELECT id FROM students where username = :uname");
            $stmt->bindParam(':uname', $Stdname);
            $stmt->execute();
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
            
        }
        
        public function getTchId($Stdname) {
            $stmt = $this->DB->prepare("SELECT id FROM teachers where username = :uname");
            $stmt->bindParam(':uname', $Stdname);
            $stmt->execute();
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
            
        }
        
        public function addStudentCourse($id, $course){
            
            $q = $this->DB->prepare( "INSERT INTO courses_Students (student_id, name) values(:id,:Cname )");
           
            $q->bindParam(':id', $id);
            $q->bindParam(':Cname', $course);
            $q->execute();
            
        }
        
        
        public function addSTeacherCourse($id, $course){
            
            $q = $this->DB->prepare( "INSERT INTO courses_Teachers (teacher_id, name) values(:id,:Cname )");
            
            $q->bindParam(':id', $id);
            $q->bindParam(':Cname', $course);
            $q->execute();
            
        }
        
        
        public function getCourses(){
            $stmt = $this->DB->prepare("SELECT name FROM coursesList");
            
            $stmt->execute();
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
                     
        }
        
        
        public function getMyCourses(){
             
            if(explode(".",$_SESSION['user'])[1]=='Student'){
                $stmt = $this->DB->prepare("SELECT courses_Students.name FROM courses_Students Join STUDENTS on courses_Students.student_id = STUDENTS.id where STUDENTS.username='".explode(".",$_SESSION['user'])[0]."'");
            }
            
            
            else  if(explode(".",$_SESSION['user'])[1]=='Professor'){
                $stmt = $this->DB->prepare("SELECT courses_Teachers.name FROM courses_Teachers Join teachers on courses_Teachers.teacher_id = teachers.id where teachers.username='".explode(".",$_SESSION['user'])[0]."'");
            }
            
            $stmt->execute();
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
            
        }
        
        
        public function setStudentgrade($courseName,$grade,$userName,$description,$grade_name){
            
            $q = $this->DB->prepare( "INSERT INTO grades (id,grade,course_id,  student_id,grade_description, grade_name) values(:id,:grade,(select courses_Students.id from courses_Students Join Students on courses_Students.student_id = STUDENTS.id where name='".$courseName."' AND STUDENTS.username='".$userName."'),(select id from STUDENTS where username='".$userName."'),:Cname ,:gradeName) ");
                                    //INSERT INTO grades (grade, course_id, student_id,grade_description) values(100,(select courses_Students.id from courses_Students Join Students on courses_Students.student_id = STUDENTS.id where name="csc330" AND STUDENTS.username="Jneto"),(select id from STUDENTS where username="Jneto"),"Exam1") 
            
            
            //select  grades.grade, grades.grade_name,grades.grade_description from grades Join students on students.id= grades.student_id Join courses_Students on (courses_Students.id=grades.course_id && courses_Students.student_id=students.id) where courses_Students="ece275";
            $id=$userName.$description.$courseName;
            $q->bindParam(':id',$id );
            $q->bindParam(':grade', $grade);
            $q->bindParam(':Cname', $description);
            $q->bindParam(':gradeName', $grade_name);
            $q->execute();
            
        }
        
        public function updateStudentgrade($courseName,$grade,$userName,$description){
            
            $id=$userName.$description.$courseName;
            
            $q = $this->DB->prepare( "UPDATE grades set grade=:grade where id='".$id."'");
            //UPDATE grades set grade=100 where id="jantonio15Assignment 2CSC330"
                        
            $q->bindParam(':grade', $grade);

            $q->execute();
            
        }
        
        public function getMyStudents($courseName){
            
            
            $stmt = $this->DB->prepare("SELECT  STUDENTS.first_name,STUDENTS.last_name,STUDENTS.username,STUDENTS.email FROM Students Join courses_Students on courses_Students.student_id = STUDENTS.id where courses_Students.name='".$courseName."'");
             
                $stmt->execute();
                return $stmt->fetchAll(PDO::FETCH_ASSOC);
                
        }
        
        
        
        public function getMyStudentsGrades($courseName, $gradeDesc){
            
            
            $stmt = $this->DB->prepare("SELECT  STUDENTS.first_name,STUDENTS.last_name,STUDENTS.username, grades.grade FROM Students Join courses_Students on courses_Students.student_id = STUDENTS.id JOIN grades on  grades.student_id = STUDENTS.id where courses_Students.name='".$courseName."' AND grades.grade_description='".$gradeDesc."'");
            //SELECT  STUDENTS.first_name,STUDENTS.last_name,STUDENTS.username, grades.grade FROM Students Join courses_Students on courses_Students.student_id = STUDENTS.id JOIN grades on  grades.student_id = STUDENTS.id where courses_Students.name='csc330' AND grades.grade_description='Assignment 2'
            $stmt->execute();
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
            
        }
        
        
        
        
        public function getGradesDescr(){
            
            
            $stmt = $this->DB->prepare("SELECT name, category  FROM gradesDescription ORDER BY name ASC");
            
            $stmt->execute();
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
            
        }
        
        public function getGradesCat(){
            
            
            $stmt = $this->DB->prepare("SELECT name FROM gradesCategory ORDER BY name ASC");
            
            $stmt->execute();
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
            
        }
        
        public function addGradeDesc($gradeDesc,$gradeCat){
            $q = $this->DB->prepare( "INSERT INTO gradesDescription (name, category) values(:name,:category )");
            
            $q->bindParam(':name', $gradeDesc);
            $q->bindParam(':category', $gradeCat);
            $q->execute();
        }
        
        public function getGrades($courseName){
            
            $stmt = $this->DB->prepare("select  grades.grade, grades.grade_name,grades.grade_description from grades Join students on students.id= grades.student_id Join courses_Students on (courses_Students.id=grades.course_id && courses_Students.student_id=students.id) where courses_Students.name='".$courseName."' AND students.username='".explode(".",$_SESSION['user'])[0]."'");
                                      //select grades.grade from grades Join students on students.id= grades.student_id Join courses_Students on (courses_Students.id=grades.course_id && courses_Students.student_id=students.id) where courses_Students.name='csc337' AND students.username='As');
            $stmt->execute();
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        }
        
        
} // End class DatabaseAdaptor

// Testing code that should not be run when a part of MVC
$theDBA = new DatabaseAdaptor ();
// $arr = $theDBA->getMoviesByYear (2000);
// print_r($arr);

// $arr = $theDBA->getMoviesByRank (6);
// print_r($arr);


?>