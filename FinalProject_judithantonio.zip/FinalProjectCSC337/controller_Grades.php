<?php


session_start ();
include 'model.php';  // for $theDBA, an instance of DataBaseAdaptor

unset($_SESSION['loginError']);

if(isset($_GET['opt'])){  
    if($_GET['opt']==1){
        $courseName=$_GET['course'];
        $arr = $theDBA->getGrades($courseName);
        
        
        echo json_encode($arr);
    }
        
}






?>
