<?php


session_start ();
include 'model.php';  // for $theDBA, an instance of DataBaseAdaptor



unset($_SESSION['loginError'] );

if(isset($_GET['GD'])  && isset($_GET['GC'])){
    $gradeDesc=$_GET['GD'];
    $gradeCat=$_GET['GC'];
    $theDBA->addGradeDesc($gradeDesc,$gradeCat);
}


if(isset($_GET['username'])  && isset($_GET['password'])&&isset($_GET['email'])  && isset($_GET['firstname'])
    &&isset($_GET['lastname'])  && isset($_GET['Users']) ) {
       
    $user=$_GET['username'];
    
    
    $passW=$_GET['password'];
    $first_name=$_GET['firstname'];
    $last_name=$_GET['lastname'];
    $email=$_GET['email'];
  //  $secQuestion=$_GET['SecQ'];
    //$hashAns=$_GET['SecA'];
    $newWhat=$_GET['Users'];
    $courseList=explode("<br>",$_GET['Clist']);
    $hashed_pwd=password_hash($passW,PASSWORD_DEFAULT);
   // $hashAns=password_hash($hashAns,PASSWORD_DEFAULT);
    
    if($newWhat=='student'){
        
       
        $arr=$theDBA->getStudentUsernames($user);
    
    
    $arr =  $theDBA->checkStudentCredentials( $user);
    
    if( count($arr)>0) {
        $_SESSION['loginError'] = 'EERROR';
        header('Location: register.php');
        
    }
    else {
      
            
         $arr =  $theDBA->addStudent($first_name,$last_name,$email,$user,$hashed_pwd);
         
         $id=$theDBA->getStdId($user);
         //print_r($id);
         //echo $id[0]['id'];
         for($i=0;$i<count($courseList);$i++){
             
             if($courseList[$i]!='')
                $theDBA->addStudentCourse($id[0]['id'],$courseList[$i]);}
        header('Location: home.php');
    }
    }
    else if($newWhat=='teacher'){
        $arr=$theDBA->getTeacherUsernames($user);
        
        
        $arr =  $theDBA->checkTeacherCredentials( $user);
        
        if( count($arr)>0) {
            $_SESSION['loginError'] = 'This username is not Available';
            header('Location: register.php');
            
        }
        else {
            
            
            $arr =  $theDBA->addTeacher($first_name,$last_name,$email,$user,$hashed_pwd);
            $id=$theDBA->getTchId($user);
            
            for($i=0;$i<count($courseList);$i++){
                
                if($courseList[$i]!='')
                    $theDBA->addSTeacherCourse($id[0]['id'],$courseList[$i]);}
            
            header('Location: home.php');
        }
    }
}


else if(isset($_GET['opt'])){
    
    if($_GET['opt']==1){
    
    $arr =  $theDBA->getCourses();
    echo json_encode($arr);}
    
    else if($_GET['opt']==2){
        
        $arr =  $theDBA->getMyCourses();
        echo json_encode($arr);
    }
    
    else if($_GET['opt']==5  && isset($_GET['course']) && isset($_GET['stdUsername']) && isset($_GET['grade'])){
        $courseName=$_GET['course'];
        $grade=$_GET['grade'];
        $userName=$_GET['stdUsername'];
        $description=$_GET['desc'];
        $grade_name=$_GET['Gname'];
        $arr =  $theDBA->setStudentgrade($courseName,$grade,$userName,$description,$grade_name);
        echo json_encode( $arr);}
        
        else if($_GET['opt']==6){
            $courseName=$_GET['course'];
            $grade=$_GET['grade'];
            $userName=$_GET['stdUsername'];
            $description=$_GET['desc'];
             $arr =  $theDBA->updateStudentgrade($courseName,$grade,$userName,$description);
            echo json_encode( $arr);
        // echo  $courseName;
        
    }
    
    else if($_GET['opt']==3  && isset($_GET['course'])){
        $courseName=$_GET['course'];
        $arr =  $theDBA->getMyStudents($courseName);
        echo json_encode( $arr);
       // echo  $courseName;
        
    }
    else if($_GET['opt']==8  && isset($_GET['course'])){
        $courseName=$_GET['course'];
        $gradeDesc=$_GET['gradeDesc'];
        $arr =  $theDBA->getMyStudentsGrades($courseName,$gradeDesc);
        echo json_encode( $arr);
        // echo  $courseName;
        
    }
    
    if($_GET['opt']==4){
        
        $arr =  $theDBA->getGradesDescr();
        echo json_encode($arr);}
    
        
        if($_GET['opt']==-5){
            
            $arr =  $theDBA->getGradesCat();
            echo json_encode($arr);}
            
}



?>